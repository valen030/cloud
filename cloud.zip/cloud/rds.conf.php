<?php $RDS_URL=""; $RDS_DB="PRODUCT"; $RDS_user="admin"; $RDS_pwd="admin123"; ?>
