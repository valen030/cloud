<form name="input" action="rds-write-config.php" method="post" class="form-horizontal">
  <div class="form-group">
    <label for="endpoint" class="col-sm-2 control-label">Endpoint</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="endpoint">
    </div>
  </div>
</form>
