CREATE TABLE PRODUCT (id INT(4) NOT NULL AUTO_INCREMENT PRIMARY KEY, pname VARCHAR(30), price VARCHAR(20), pdesc VARCHAR(100), category VARCHAR(30));

INSERT INTO PRODUCT (pname, price, pdesc, category) VALUES ("Mark Chicken", "12.20", "Burger with chicken","Main Dish"), ( "Fish Burger", "11.20", "Burger with fish", "Main Dish" ), ( "Mark Nugget", "10.20", "Classic nugget", "Side Dish");