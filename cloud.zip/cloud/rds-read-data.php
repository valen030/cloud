<h2>Address Book</h2><p>
<?php
  //This is a simple address book example for testing with RDS

  include('rds.conf.php');

  // Set address book variables
  isset($_REQUEST['mode']) ? $mode=$_REQUEST['mode'] : $mode="";
  isset($_REQUEST['id']) ? $id=$_REQUEST['id'] : $id="";
  isset($_REQUEST['pname']) ? $lastname=$_REQUEST['pname'] : $pname="";
  isset($_REQUEST['price']) ? $firstname=$_REQUEST['price'] : $price="";
  isset($_REQUEST['pdesc']) ? $phone=$_REQUEST['pdesc'] : $pdesc="";
  isset($_REQUEST['category']) ? $email=$_REQUEST['category'] : $category="";

  // Connect to the RDS database
  mysql_connect($RDS_URL, $RDS_user, $RDS_pwd) or die(mysql_error());

  mysql_select_db($RDS_DB) or die(mysql_error());

if ( $mode=="add")
 {
 Print '<h2>Add Dishes</h2>
 <p>
 <form action=';
 echo $_SERVER['PHP_SELF'];
 Print '
 method=post>
 <table>
 <tr><td>Name:</td><td><input type="text" name="pname" /></td></tr>
 <tr><td>Price:</td><td><input type="text" name="price" /></td></tr>
 <tr><td>Description:</td><td><input type="text" name="pdesc" /></td></tr>
 <tr><td>Category:</td><td><input type="text" name="category" /></td></tr>
 <tr><td colspan="2" align="center"><input type="submit" /></td></tr>
 <input type=hidden name=mode value=added>
 </table>
 </form> <p>';
 }

 if ( $mode=="added")
 {
 mysql_query ("INSERT INTO address (pname, price, pdesc, category) VALUES ('$pname', '$price', '$pdesc', '$category')");
 }

if ( $mode=="edit")
 {
 Print '<h2>Edit Contact</h2>
 <p>
 <form action=';
 echo $_SERVER['PHP_SELF'];
 Print '
 method=post>
 <table>
 <tr><td>Name:</td><td><input type="text" value="';
 Print $pname;
 print '" name="pname" /></td></tr>
 <tr><td>Price:</td><td><input type="text" value="';
 Print $price;
 print '" name="price" /></td></tr>
 <tr><td>Description:</td><td><input type="text" value="';
 Print $pdesc;
 print '" name="pdesc" /></td></tr>
 <tr><td>Category:</td><td><input type="text" value="';
 Print $category;
 print '" name="category" /></td></tr>
 <tr><td colspan="3" align="center"><input type="submit" /></td></tr>
 <input type=hidden name=mode value=edited>
 <input type=hidden name=id value=';
 Print $id;
 print '>
 </table>
 </form> <p>';
 }

 if ( $mode=="edited")
 {
 mysql_query ("UPDATE address SET pname = '$pname', price = '$price', pdesc = '$pdesc', category = '$category' WHERE id = $id");
 Print "Data Updated!<p>";
 }

if ( $mode=="remove")
 {
 mysql_query ("DELETE FROM address where id=$id");
 Print "Dish has been removed <p>";
 }

 $data = mysql_query("SELECT * FROM address ORDER BY pname ASC")
 or die(mysql_error());
 Print "<table border cellpadding=3>";
 Print "<tr><th width=100>Name</th> " .
   "<th width=100>Price</th> " .
   "<th width=100>Description</th> " .
   "<th width=200>Category</th> " .
   "<th width=100 colspan=3>Admin</th></tr>";
 Print "<td colspan=6 align=right> " .
   "<a href=" .$_SERVER['PHP_SELF']. "?mode=add>Add Contact</a></td>";
 while($info = mysql_fetch_array( $data ))
 {
 Print "<tr><td>".$info['pname'] . "</td> ";
 Print "<td>".$info['price'] . "</td> ";
 Print "<td>".$info['pdesc'] . "</td> ";
 Print "<td>".$info['category'] . "</td>";
 Print "<td><a href=" .$_SERVER['PHP_SELF']. "?id=" . $info['id'] ."&pname=" . $info['pname'] . "&price=" . $info['price'] . "&pdesc=" . $info['pdesc'] ."&category=" . $info['category'] . "&mode=edit>Edit</a></td>";
 Print "<td><a href=" .$_SERVER['PHP_SELF']. "?id=" . $info['id'] ."&mode=remove>Remove</a></td></tr>";
 }
 Print "</table>";
?>
